import React, { useRef, useState } from "react";
import io from "socket.io-client";

const SOCKET_SERVER_URL = "http://localhost:5000";

function App() {
  const [joined, setJoined] = useState(false);
  const [roomId, setRoomId] = useState("");
  const [clientId, setClientId] = useState("");
  const localVideoRef = useRef(null);
  const remoteVideoRef = useRef(null);
  const peerConnectionRef = useRef(null);
  const socketRef = useRef(null);

  const constraints = { video: true, audio: true };

  const joinRoom = async () => {
    socketRef.current = io(SOCKET_SERVER_URL);
    setJoined(true);

    socketRef.current.emit("join", roomId);

    socketRef.current.on("joined", (id) => {
      setClientId(id);
      startLocalStream();
    });

    socketRef.current.on("offer", async (offer) => {
      if (!peerConnectionRef.current) await setupPeerConnection(false);
      await peerConnectionRef.current.setRemoteDescription(offer);
      const answer = await peerConnectionRef.current.createAnswer();
      await peerConnectionRef.current.setLocalDescription(answer);
      socketRef.current.emit("answer", { answer, roomId });
    });

    socketRef.current.on("answer", async (answer) => {
      await peerConnectionRef.current.setRemoteDescription(answer);
    });

    socketRef.current.on("ice-candidate", async (candidate) => {
      if (peerConnectionRef.current) {
        await peerConnectionRef.current.addIceCandidate(candidate);
      }
    });
  };

  const startLocalStream = async () => {
    const stream = await navigator.mediaDevices.getUserMedia(constraints);
    localVideoRef.current.srcObject = stream;
    await setupPeerConnection(true, stream);
  };

  const setupPeerConnection = async (isInitiator, stream = null) => {
    peerConnectionRef.current = new RTCPeerConnection();
    if (stream) {
      stream.getTracks().forEach(track => {
        peerConnectionRef.current.addTrack(track, stream);
      });
    }

    peerConnectionRef.current.ontrack = (event) => {
      remoteVideoRef.current.srcObject = event.streams[0];
    };

    peerConnectionRef.current.onicecandidate = (event) => {
      if (event.candidate) {
        socketRef.current.emit("ice-candidate", { candidate: event.candidate, roomId });
      }
    };

    if (isInitiator) {
      const offer = await peerConnectionRef.current.createOffer();
      await peerConnectionRef.current.setLocalDescription(offer);
      socketRef.current.emit("offer", { offer, roomId });
    }
  };

  return (
    <div style={{ padding: "2rem" }}>
      <h2>React Video Conferencing App</h2>
      {!joined ? (
        <div>
          <input
            type="text"
            placeholder="Room ID"
            value={roomId}
            onChange={e => setRoomId(e.target.value)}
          />
          <button onClick={joinRoom} disabled={!roomId}>Join Room</button>
        </div>
      ) : (
        <div style={{ display: "flex", gap: "2rem" }}>
          <div>
            <h3>Local Video</h3>
            <video ref={localVideoRef} autoPlay playsInline muted width="400" height="300" />
          </div>
          <div>
            <h3>Remote Video</h3>
            <video ref={remoteVideoRef} autoPlay playsInline width="400" height="300" />
          </div>
        </div>
      )}
    </div>
  );
}

export default App;